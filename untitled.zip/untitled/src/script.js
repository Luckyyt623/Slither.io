// server.js
const WebSocket = require('ws');
const express = require('express');
const app = express();
const server = require('http').createServer(app);
const wss = new WebSocket.Server({ server });

let connections = [];

wss.on('connection', (ws) => {
    connections.push(ws);
    ws.on('message', (data) => {
        // Broadcast data to all connected clients
        connections.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(data);
            }
        });
    });
    ws.on('close', () => {
        connections = connections.filter(conn => conn !== ws);
    });
});

app.use(express.static('public')); // Serve static files from the 'public' folder

server.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
